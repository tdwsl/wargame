package part02;

import java.awt.Color;
import java.awt.Font;

// Make sure to import the correct Console definition
// java.io contains a different definition
import console.Console;	

public class ConsoleTest {

	public static void main(String[] args) {
		// This will create a new Console instance
		// - a value of 'true' enables keyboard input
		Console con = new Console(true);

		// Set the width and height for the console
		con.setSize(400, 200);
		
		// Make sure the console is visible to the user
		con.setVisible(true);
		
		// You can modify the Font and Colour
		con.setFont( new Font("Courier", Font.BOLD, 30) );
		con.setColour( Color.blue );
		
		// Print a message on the console
		con.print("Enter a String: ");
		
		// Read the value from the console
		String str = con.readLn();
		
		//  Display the value
		con.println("You typed: " + str);
	}

}
