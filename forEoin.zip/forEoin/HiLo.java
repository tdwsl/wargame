package part02;

import java.awt.Color;
import java.awt.Font;
import java.util.Random;

import javax.swing.ImageIcon;

import console.Console;

public class HiLo {

	public static void main(String[] args) {
		Console con = new Console(true);
		while( true ) {
			if ( !playGame(con) ) {
				break;
			}
		}
		System.exit(1);
	}

	private static boolean playGame(Console con) {
		con.setSize(700, 400);
		con.setVisible(true);

		// set background colour for console
		con.setBgColour(Color.BLACK);
		// set font for console
		con.setFont(new Font("Courier", Font.BOLD, 20));
		// set text colour for console
		con.setColour(Color.WHITE);

		Random rand = new Random();
		final int MAX = 7;
		ImageIcon allCards[] = new ImageIcon[MAX];
		int attempts = 0;
		boolean badGuess = false;

		// random suit and card number (for first card)
		int suit = rand.nextInt(4) + 1;
		int card = rand.nextInt(13) + 1;
		allCards[attempts++] = selectCard(suit, card);

		while (attempts < MAX && !badGuess){
			displayCards(allCards, con);
			con.print("Higher (H) or Lower (L): ");
			String guess = con.readLn();
			guess = guess.trim();
			int last = card;
			
			// next card
			suit = rand.nextInt(4) + 1;
			card = rand.nextInt(13) + 1;
			
			// outcome
			switch(guess) {
			case "H"	:
			case "h"	: 	badGuess = card < last;
							break;
			case "L"	:
			case "l"	:	badGuess = card > last;
			}
			allCards[attempts] = selectCard(suit, card);
			attempts++;
		} 

		displayCards(allCards, con);
		if (badGuess) {
			con.println("Game Over - You Lose!");
		} else {
			con.println("Game Over - You Win!");
		}
		con.print("Another game? (Y/N): ");
		String answer = con.readLn();
		answer = answer.trim();
		return ( answer.equals("Y") || answer.equals("y") );
	}
	
	private static void displayCards(ImageIcon cards[], Console con) {
		con.clear();
		con.println("++++++++ Hi Lo ++++++++");

		for(ImageIcon img : cards) {
			if ( img != null ) {
				con.print(img);
				con.print(" ");
			}
		}
		con.println();
	}

	private static ImageIcon selectCard(int suit, int card) {
		String userdir = System.getProperty("user.dir");
		String path = userdir + "/Images/Cards/";

		switch (suit) {
		case 1:
			path += "Diamonds/";
			break;
		case 2:
			path += "Hearts/";
			break;
		case 3:
			path += "Clubs/";
			break;
		case 4:
			path += "Spades/";
			break;
		}

		switch (card) {
		case 1:
			path += "A.png";
			break;
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			path += card + ".png";
			break;
		case 11:
			path += "J.png";
			break;
		case 12:
			path += "Q.png";
			break;
		case 13:
			path += "K.png";
		}
		return new ImageIcon(path);
	}

}
